Patternaut review samples

Five short sounds, synthesised for this purpose, so nothing here belongs to anyone else.

1. In Patternaut, press Generate a Beat.
2. Select the five WAV files in name order and drag them onto the Instruments panel on the
   right. They become instruments 00 to 04, which are the numbers the generated beat uses.
3. Press Space. The pattern plays through them and the row being heard is highlighted.
   Click a step or a row number to hear just that. Press Space again to stop.
